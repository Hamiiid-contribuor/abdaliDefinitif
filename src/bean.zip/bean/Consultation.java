/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.sql.Time;
import java.util.Date;

/**
 *
 * @author hamid
 */
public class Consultation {

    private int id;
    private Date dateConsultation;
    private Time heureConsultation;
    private String lieuConsultation;
    private int deleted;
    private Patient patient;
    //private Medcin medcin;

    public Consultation() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDateConsultation() {
        return dateConsultation;
    }

    public void setDateConsultation(Date dateConsultation) {
        this.dateConsultation = dateConsultation;
    }

    public Time getHeureConsultation() {
        return heureConsultation;
    }

    public void setHeureConsultation(Time heureConsultation) {
        this.heureConsultation = heureConsultation;
    }

    public String getLieuConsultation() {
        return lieuConsultation;
    }

    public void setLieuConsultation(String lieuConsultation) {
        this.lieuConsultation = lieuConsultation;
    }

    public int getDeleted() {
        return deleted;
    }

    public void setDeleted(int deleted) {
        this.deleted = deleted;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

//    public Medcin getMedcin() {
//        return medcin;
//    }
//
//    public void setMedcin(Medcin medcin) {
//        this.medcin = medcin;
//    }

}
