/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.util.List;

/**
 *
 * @author hamid
 */
public class Ordenance {

    private int id; // auto ??
    private String traitementPresent;
    private String commentaire;
    private Patient patient;
    private List<Medicament> medicaments;
    //private Medcin medcin = new Medcin();

    public Ordenance() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTraitementPresent() {
        return traitementPresent;
    }

    public void setTraitementPresent(String traitementPresent) {
        this.traitementPresent = traitementPresent;
    }

    public String getCommentaire() {
        return commentaire;
    }

    public void setCommentaire(String commentaire) {
        this.commentaire = commentaire;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public List<Medicament> getMedicaments() {
        return medicaments;
    }

    public void setMedicaments(List<Medicament> medicaments) {
        this.medicaments = medicaments;
    }

//    public Medcin getMedcin() {
//        return medcin;
//    }
//
//    public void setMedcin(Medcin medcin) {
//        this.medcin = medcin;
//    }
    
    
    
    
    

}
